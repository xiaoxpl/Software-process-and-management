# Software-process-and-management
个人软件过程中的基本理念和各个台阶上对应的软件过程和活动。
